struct SignKill
{
	int ID;
	int Time;
};
